"use client"
import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { Send, Smile, Paperclip, Search, MoreVertical, CheckCheck } from 'lucide-react';
import EmojiPicker from 'emoji-picker-react';

export default function WhatsApp() {
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [showEmoji, setShowEmoji] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Real-time Fetching
  useEffect(() => {
    const fetchInitial = async () => {
      const { data } = await supabase.from('messages').select('*').order('created_at', { ascending: true });
      if (data) setMessages(data);
    };
    fetchInitial();

    const channel = supabase.channel('chat-room')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, (payload) => {
        setMessages((current) => [...current, payload.new]);
      }).subscribe();

    return () => { supabase.removeChannel(channel); };
  }, []);

  const sendMessage = async (e: any) => {
    e.preventDefault();
    if (!input.trim()) return;
    
    // Using a hardcoded ID for now to keep it simple
    await supabase.from('messages').insert([{ content: input, user_id: 'user_1' }]);
    setInput('');
    setShowEmoji(false);
  };

  return (
    <div className="flex h-screen bg-[#0b141a] overflow-hidden">
      {/* Sidebar (Simplified) */}
      <div className="hidden md:flex w-[30%] flex-col border-r border-[#222d34]">
        <div className="h-16 bg-[#202c33] p-4 flex items-center justify-between">
          <div className="w-10 h-10 rounded-full bg-slate-500" />
          <MoreVertical className="text-[#aebac1] cursor-pointer" />
        </div>
        <div className="p-3 bg-[#111b21]">
          <div className="bg-[#202c33] rounded-lg flex items-center px-4 py-1">
            <Search className="text-[#8696a0] w-4" />
            <input className="bg-transparent p-2 text-sm outline-none w-full" placeholder="Search chats" />
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col relative">
        <div className="chat-wallpaper"></div>
        
        {/* Header */}
        <header className="h-16 bg-[#202c33] z-10 flex items-center px-4 gap-4 shadow-md">
          <div className="w-10 h-10 rounded-full bg-blue-500" />
          <div>
            <h1 className="text-sm font-bold">Project Group</h1>
            <p className="text-[11px] text-[#8696a0]">online</p>
          </div>
        </header>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 z-10 flex flex-col gap-2">
          {messages.map((msg) => (
            <div key={msg.id} className={`max-w-[70%] p-2 px-3 rounded-lg text-sm relative shadow-sm
              ${msg.user_id === 'user_1' ? 'bg-[#005c4b] self-end rounded-tr-none' : 'bg-[#202c33] self-start rounded-tl-none'}`}>
              <p>{msg.content}</p>
              <div className="flex items-center justify-end gap-1 mt-1">
                <span className="text-[10px] text-[#8696a0]">12:00 PM</span>
                {msg.user_id === 'user_1' && <CheckCheck size={14} className="text-[#53bdeb]" />}
              </div>
            </div>
          ))}
          <div ref={scrollRef} />
        </div>

        {/* Input Bar */}
        <footer className="min-h-[60px] bg-[#202c33] z-10 p-2 flex items-center gap-3">
          <Smile className="text-[#8696a0] cursor-pointer" onClick={() => setShowEmoji(!showEmoji)} />
          {showEmoji && <div className="absolute bottom-20 z-50"><EmojiPicker theme="dark" onEmojiClick={(e) => setInput(prev => prev + e.emoji)} /></div>}
          <Paperclip className="text-[#8696a0] -rotate-45 cursor-pointer" />
          <form className="flex-1" onSubmit={sendMessage}>
            <input 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type a message" 
              className="w-full bg-[#2a3942] rounded-lg py-2 px-4 outline-none text-sm"
            />
          </form>
          <Send className="text-[#8696a0] cursor-pointer" onClick={sendMessage} />
        </footer>
      </div>
    </div>
  );
}